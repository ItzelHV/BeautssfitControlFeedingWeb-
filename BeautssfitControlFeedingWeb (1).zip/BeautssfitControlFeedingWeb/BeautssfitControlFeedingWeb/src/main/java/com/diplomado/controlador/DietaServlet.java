/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.diplomado.controlador;

import com.diplomado.modelo.Dieta;
import com.diplomado.modelo.conexion;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/DietaServlet")
public class DietaServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Logica para agregar, editar o eliminar dietas
        String action = request.getParameter("action");

        try (Connection conn = conexion.getConnection()) {
            if (null != action) switch (action) {
                case "create":{
                    int atletaId = Integer.parseInt(request.getParameter("atletaId"));
                    String comida = request.getParameter("comida");
                    String hora = request.getParameter("hora");
                    String sql = "INSERT INTO dietas (atleta_id, comida, hora) VALUES (?, ?, ?)";
                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                        stmt.setInt(1, atletaId);
                        stmt.setString(2, comida);
                        stmt.setString(3, hora);
                        stmt.executeUpdate();
                    }       break;
                    }
            // Codigo para actualizar una dieta
                case "update":
                    break;
                case "delete":{
                    int id = Integer.parseInt(request.getParameter("id"));
                    String sql = "DELETE FROM dietas WHERE id = ?";
                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                        stmt.setInt(1, id);
                        stmt.executeUpdate();
                    }       break;
                    }
                default:
                    break;
            }
        } catch (SQLException e) {
        }
        //Eliminar
if ("delete".equals(action)) {
    int id = Integer.parseInt(request.getParameter("id"));
    String sql = "DELETE FROM dietas WHERE id = ?";
    try (Connection conn = conexion.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, id);
        stmt.executeUpdate();
    } catch (SQLException e) {
    }
    response.sendRedirect("detalleDieta.jsp?atletaId=" + request.getParameter("atletaId"));
}

        response.sendRedirect("detalleDieta.jsp?atletaId=" + request.getParameter("atletaId"));
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Mostrar detalle de la dieta para un atleta
        int atletaId = Integer.parseInt(request.getParameter("atletaId"));
        List<Dieta> dietas = new ArrayList<>();
        try (Connection conn = conexion.getConnection()) {
            String sql = "SELECT * FROM dietas WHERE atleta_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, atletaId);
                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    Dieta dieta = new Dieta(
                        rs.getInt("id"),
                        rs.getInt("atleta_id"),
                        rs.getString("comida"),
                        rs.getString("hora")
                    );
                    dietas.add(dieta);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        request.setAttribute("listaDietas", dietas);
        request.getRequestDispatcher("detalleDieta.jsp").forward(request, response);
    }
}