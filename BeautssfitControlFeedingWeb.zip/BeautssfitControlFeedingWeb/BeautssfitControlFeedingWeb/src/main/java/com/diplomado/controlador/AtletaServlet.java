/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.diplomado.controlador;

import com.diplomado.modelo.Atleta;
import com.diplomado.modelo.conexion;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/AtletaServlet")
public class AtletaServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Logica para agregar, editar o eliminar atletas
        String action = request.getParameter("action");

        try (Connection conn = conexion.getConnection()) {
            if (null != action) switch (action) {
                case "create":{
                    String nombre = request.getParameter("nombre");
                    int edad = Integer.parseInt(request.getParameter("edad"));
                    float peso = Float.parseFloat(request.getParameter("peso"));
                    float altura = Float.parseFloat(request.getParameter("altura"));
                    String sql = "INSERT INTO atletas (nombre, edad, peso, altura) VALUES (?, ?, ?, ?)";
                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                        stmt.setString(1, nombre);
                        stmt.setInt(2, edad);
                        stmt.setFloat(3, peso);
                        stmt.setFloat(4, altura);
                        stmt.executeUpdate();
                    }       break;
                    }
            // Codigo para actualizar un atleta
                case "update":
                    break;
                case "delete":{
                    int id = Integer.parseInt(request.getParameter("id"));
                    String sql = "DELETE FROM atletas WHERE id = ?";
                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                        stmt.setInt(1, id);
                        stmt.executeUpdate();
                    }       break;
                    }
                default:
                    break;
            }
        } catch (SQLException e) {
        }
        //eliminar
        if ("delete".equals(action)) {
    int id = Integer.parseInt(request.getParameter("id"));
    String sql = "DELETE FROM atletas WHERE id = ?";
    try (Connection conn = conexion.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, id);
        stmt.executeUpdate();
    } catch (SQLException e) {
    }
    response.sendRedirect("listaAtletas.jsp");
}


        response.sendRedirect("listaAtletas.jsp");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Mostrar lista de atletas
        List<Atleta> atletas = new ArrayList<>();
        try (Connection conn = conexion.getConnection()) {
            String sql = "SELECT * FROM atletas";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    Atleta atleta = new Atleta(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getInt("edad"),
                        rs.getFloat("peso"),
                        rs.getFloat("altura")
                    );
                    atletas.add(atleta);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        request.setAttribute("listaAtletas", atletas);
        request.getRequestDispatcher("listaAtletas.jsp").forward(request, response);
    }
}